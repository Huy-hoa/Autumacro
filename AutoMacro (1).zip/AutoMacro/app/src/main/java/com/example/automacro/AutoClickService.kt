package com.example.automacro

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

class AutoClickService : AccessibilityService() {

    companion object {
        var instance: AutoClickService? = null
    }

    private class Marker(val view: TextView, val lp: WindowManager.LayoutParams)

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val wm by lazy { getSystemService(WINDOW_SERVICE) as WindowManager }
    private val markers = mutableListOf<Marker>()
    private var panel: View? = null
    private var playBtn: Button? = null
    private var job: Job? = null

    override fun onServiceConnected() {
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onDestroy() {
        hidePanel()
        scope.cancel()
        instance = null
        super.onDestroy()
    }

    // ---------- UI nổi ----------

    private fun params(touchable: Boolean) = WindowManager.LayoutParams(
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
            (if (touchable) 0 else WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE),
        PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.START }

    fun showPanel() {
        if (panel != null) return
        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()

        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(0xE6222222.toInt())
            setPadding(dp(4), dp(4), dp(4), dp(4))
        }
        val handle = TextView(this).apply {
            text = "⠿"
            textSize = 22f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(dp(8), 0, dp(8), 0)
        }
        fun btn(t: String, f: () -> Unit) = Button(this).apply {
            text = t
            minWidth = 0
            minimumWidth = 0
            setOnClickListener { f() }
        }
        val play = btn("▶") { toggleRun() }
        playBtn = play

        bar.addView(handle)
        bar.addView(btn("＋") { addMarker() })
        bar.addView(btn("－") { removeMarker() })
        bar.addView(play)
        bar.addView(btn("✕") { hidePanel() })

        val lp = params(true).apply { x = dp(16); y = dp(120) }
        attachDrag(handle, lp, bar)
        wm.addView(bar, lp)
        panel = bar
    }

    fun hidePanel() {
        stopRun()
        markers.forEach { runCatching { wm.removeView(it.view) } }
        markers.clear()
        panel?.let { runCatching { wm.removeView(it) } }
        panel = null
        playBtn = null
    }

    private fun attachDrag(touch: View, lp: WindowManager.LayoutParams, target: View) {
        var sx = 0
        var sy = 0
        var tx = 0f
        var ty = 0f
        touch.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = sx + (e.rawX - tx).toInt()
                    lp.y = sy + (e.rawY - ty).toInt()
                    wm.updateViewLayout(target, lp)
                }
            }
            true
        }
    }

    private fun addMarker() {
        val dm = resources.displayMetrics
        val size = (48 * dm.density).toInt()
        val tv = TextView(this).apply {
            text = "${markers.size + 1}"
            textSize = 16f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0xAAFF3B30.toInt())
                setStroke(4, Color.WHITE)
            }
        }
        val lp = params(true).apply {
            width = size
            height = size
            x = (dm.widthPixels - size) / 2
            y = (dm.heightPixels - size) / 2 + markers.size * size
        }
        attachDrag(tv, lp, tv)
        wm.addView(tv, lp)
        markers.add(Marker(tv, lp))
    }

    private fun removeMarker() {
        if (markers.isEmpty()) return
        val m = markers.removeAt(markers.lastIndex)
        runCatching { wm.removeView(m.view) }
    }

    private fun setMarkersTouchable(touchable: Boolean) {
        markers.forEach {
            it.lp.flags = if (touchable) {
                it.lp.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
            } else {
                it.lp.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
            }
            wm.updateViewLayout(it.view, it.lp)
        }
    }

    // ---------- Chạy macro ----------

    private fun toggleRun() {
        if (job?.isActive == true) { stopRun(); return }
        if (markers.isEmpty()) {
            Toast.makeText(this, "Hãy thêm ít nhất 1 điểm chạm (＋)", Toast.LENGTH_SHORT).show()
            return
        }
        val prefs = getSharedPreferences("cfg", MODE_PRIVATE)
        val interval = prefs.getLong("interval", 1000L).coerceAtLeast(50L)
        val loops = prefs.getInt("loops", 0)

        val points = markers.map {
            val loc = IntArray(2)
            it.view.getLocationOnScreen(loc)
            Pair(loc[0] + it.view.width / 2f, loc[1] + it.view.height / 2f)
        }

        setMarkersTouchable(false)
        playBtn?.text = "■"
        job = scope.launch {
            var n = 0
            while (isActive && (loops == 0 || n < loops)) {
                for (p in points) {
                    if (!isActive) break
                    tap(p.first, p.second)
                    delay(interval)
                }
                n++
            }
            stopRun()
        }
    }

    private fun stopRun() {
        job?.cancel()
        job = null
        if (panel != null) {
            setMarkersTouchable(true)
            playBtn?.text = "▶"
        }
    }

    private suspend fun tap(x: Float, y: Float) = suspendCancellableCoroutine<Unit> { c ->
        val path = Path().apply { moveTo(x, y) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 50))
            .build()
        val cb = object : GestureResultCallback() {
            override fun onCompleted(g: GestureDescription?) { if (c.isActive) c.resume(Unit) }
            override fun onCancelled(g: GestureDescription?) { if (c.isActive) c.resume(Unit) }
        }
        if (!dispatchGesture(gesture, cb, null) && c.isActive) c.resume(Unit)
    }
}
