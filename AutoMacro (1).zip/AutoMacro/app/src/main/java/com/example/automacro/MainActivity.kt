package com.example.automacro

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("cfg", MODE_PRIVATE)
        val pad = (16 * resources.displayMetrics.density).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        root.addView(TextView(this).apply {
            text = "AutoMacro – tự động chạm màn hình\n\n" +
                "1) Bật dịch vụ trợ năng cho AutoMacro.\n" +
                "2) Nhập thông số bên dưới.\n" +
                "3) Bấm 'Hiện bảng điều khiển', dùng ＋ để thêm điểm chạm, kéo điểm đến vị trí cần chạm, bấm ▶ để chạy."
        })

        val interval = EditText(this).apply {
            hint = "Khoảng cách giữa các lần chạm (ms)"
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(prefs.getLong("interval", 1000).toString())
        }
        val loops = EditText(this).apply {
            hint = "Số vòng lặp (0 = vô hạn)"
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(prefs.getInt("loops", 0).toString())
        }
        root.addView(interval)
        root.addView(loops)

        root.addView(Button(this).apply {
            text = "1. Bật dịch vụ trợ năng"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        root.addView(Button(this).apply {
            text = "2. Hiện bảng điều khiển nổi"
            setOnClickListener {
                prefs.edit()
                    .putLong("interval", (interval.text.toString().toLongOrNull() ?: 1000L).coerceAtLeast(50L))
                    .putInt("loops", loops.text.toString().toIntOrNull() ?: 0)
                    .apply()
                val svc = AutoClickService.instance
                if (svc == null) {
                    Toast.makeText(this@MainActivity, "Hãy bật dịch vụ trợ năng trước", Toast.LENGTH_LONG).show()
                } else {
                    svc.showPanel()
                    moveTaskToBack(true)
                }
            }
        })
        setContentView(root)
    }
}
