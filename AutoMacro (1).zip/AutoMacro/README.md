# AutoMacro (v1 – auto tap)
1. Mở thư mục này bằng Android Studio (Koala trở lên), chờ Gradle sync.
2. Cắm điện thoại (bật USB debugging) và bấm Run, hoặc Build > Build APK.
3. Trên điện thoại: mở app > "Bật dịch vụ trợ năng" > bật AutoMacro.
   (Android 13+ nếu cài APK ngoài: Cài đặt > Ứng dụng > AutoMacro > ⋮ > Cho phép cài đặt bị hạn chế.)
4. "Hiện bảng điều khiển nổi" > ＋ thêm điểm, kéo vào vị trí, ▶ chạy, ■ dừng.
