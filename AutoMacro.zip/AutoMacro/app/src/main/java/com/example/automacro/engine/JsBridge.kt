package com.example.automacro.engine

import app.cash.quickjs.QuickJs
import com.example.automacro.logging.LogLevel
import com.example.automacro.logging.LogStore

class MacroStopped : RuntimeException("Macro đã dừng")

class RunControl {
    @Volatile var stop = false
    @Volatile var exited = false
    fun check() { if (stop) throw MacroStopped() }
}

interface LogBridge { fun write(level: String, msg: String) }
interface TimeBridge { fun delay(ms: String) }
interface SysBridge { fun exit() }

object JsBridge {
    fun install(qjs: QuickJs, ctl: RunControl, source: String) {
        qjs.set("__log", LogBridge::class.java, object : LogBridge {
            override fun write(level: String, msg: String) {
                ctl.check()
                val lv = when (level) {
                    "W" -> LogLevel.WARN
                    "E" -> LogLevel.ERROR
                    "D" -> LogLevel.DEBUG
                    else -> LogLevel.INFO
                }
                LogStore.add(lv, msg, source)
            }
        })
        qjs.set("__time", TimeBridge::class.java, object : TimeBridge {
            override fun delay(ms: String) {
                var left = (ms.toDoubleOrNull() ?: 0.0).toLong().coerceAtLeast(0L)
                ctl.check()
                while (left > 0) {
                    val step = if (left < 25L) left else 25L
                    try {
                        Thread.sleep(step)
                    } catch (e: InterruptedException) {
                        ctl.stop = true
                    }
                    left -= step
                    ctl.check()
                }
            }
        })
        qjs.set("__sys", SysBridge::class.java, object : SysBridge {
            override fun exit() {
                ctl.exited = true
                ctl.stop = true
                throw MacroStopped()
            }
        })
    }

    const val PRELUDE = """
(function (g) {
  var t0 = Date.now();
  function fmt(args) {
    var out = [];
    for (var i = 0; i < args.length; i++) {
      var v = args[i];
      if (typeof v === 'string') out.push(v);
      else if (v instanceof Error) out.push(String(v));
      else {
        var s;
        try { s = JSON.stringify(v); } catch (e) { s = undefined; }
        out.push(s === undefined ? String(v) : s);
      }
    }
    return out.join(' ');
  }
  function mk(level) { return function () { __log.write(level, fmt(arguments)); }; }
  g.Log = { info: mk('I'), warn: mk('W'), error: mk('E'), debug: mk('D') };
  g.console = { log: g.Log.info, info: g.Log.info, warn: g.Log.warn, error: g.Log.error, debug: g.Log.debug };
  g.Time = {
    delay: function (ms) { __time.delay(String(Number(ms) || 0)); },
    delaySec: function (s) { __time.delay(String((Number(s) || 0) * 1000)); },
    now: function () { return Date.now(); },
    elapsed: function () { return Date.now() - t0; }
  };
  g.Sys = { exit: function () { __sys.exit(); } };
})(globalThis);
"""
}
