package com.example.automacro.ui

import android.os.SystemClock
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import kotlin.math.min

class Palette(
    val keyword: Color, val string: Color, val number: Color, val comment: Color,
    val api: Color, val literal: Color, val matchBg: Color, val errorBg: Color
) {
    companion object {
        val Light = Palette(
            Color(0xFF0033B3), Color(0xFF067D17), Color(0xFF1750EB), Color(0xFF8C8C8C),
            Color(0xFF871094), Color(0xFF0033B3), Color(0x66FFEB3B), Color(0x33F44336)
        )
        val Dark = Palette(
            Color(0xFFCC7832), Color(0xFF6A8759), Color(0xFF6897BB), Color(0xFF808080),
            Color(0xFF9876AA), Color(0xFFCC7832), Color(0x66FFEB3B), Color(0x44F44336)
        )
    }
}

object JsHighlighter {
    private val keywords = setOf(
        "var", "let", "const", "function", "return", "if", "else", "for", "while", "do", "switch", "case",
        "break", "continue", "default", "new", "try", "catch", "finally", "throw", "typeof", "instanceof",
        "in", "of", "this", "class", "extends", "async", "await", "yield", "delete", "void"
    )
    private val literals = setOf("true", "false", "null", "undefined", "NaN", "Infinity")
    private val apis = setOf(
        "Log", "Time", "Sys", "console", "Math", "JSON", "Date", "Array", "Object", "String", "Number", "Boolean"
    )

    fun lineBounds(src: String, line: Int): Pair<Int, Int>? {
        var start = 0
        var ln = 1
        while (ln < line) {
            val nl = src.indexOf('\n', start)
            if (nl < 0) return null
            start = nl + 1
            ln++
        }
        var end = src.indexOf('\n', start)
        if (end < 0) end = src.length
        return Pair(start, end)
    }

    fun highlight(src: String, p: Palette, match: IntRange?, errorLine: Int?): AnnotatedString =
        buildAnnotatedString {
            append(src)
            fun paint(s: Int, e: Int, c: Color) {
                if (e > s) addStyle(SpanStyle(color = c), s, e)
            }
            val n = src.length
            var i = 0
            while (i < n) {
                val c = src[i]
                if (c == '/' && i + 1 < n && src[i + 1] == '/') {
                    var j = i
                    while (j < n && src[j] != '\n') j++
                    paint(i, j, p.comment)
                    i = j
                } else if (c == '/' && i + 1 < n && src[i + 1] == '*') {
                    val k = src.indexOf("*/", i + 2)
                    val j = if (k < 0) n else k + 2
                    paint(i, j, p.comment)
                    i = j
                } else if (c == '"' || c == '\'' || c == '`') {
                    var j = i + 1
                    while (j < n && src[j] != c) {
                        if (src[j] == '\n' && c != '`') break
                        if (src[j] == '\\') j++
                        j++
                    }
                    j = if (j < n && src[j] == c) j + 1 else min(j, n)
                    paint(i, j, p.string)
                    i = j
                } else if (c.isDigit()) {
                    var j = i
                    while (j < n && (src[j].isLetterOrDigit() || src[j] == '.')) j++
                    paint(i, j, p.number)
                    i = j
                } else if (c.isLetter() || c == '_' || c == '$') {
                    var j = i
                    while (j < n && (src[j].isLetterOrDigit() || src[j] == '_' || src[j] == '$')) j++
                    val w = src.substring(i, j)
                    val col = when {
                        w in keywords -> p.keyword
                        w in literals -> p.literal
                        w in apis -> p.api
                        else -> null
                    }
                    if (col != null) paint(i, j, col)
                    i = j
                } else {
                    i++
                }
            }
            if (match != null) {
                val s = match.first.coerceIn(0, n)
                val e = (match.last + 1).coerceIn(0, n)
                if (e > s) addStyle(SpanStyle(background = p.matchBg), s, e)
            }
            if (errorLine != null) {
                val b = lineBounds(src, errorLine)
                if (b != null && b.second > b.first) addStyle(SpanStyle(background = p.errorBg), b.first, b.second)
            }
        }
}

class JsVisualTransformation(
    private val palette: Palette,
    private val match: IntRange?,
    private val errorLine: Int?
) : VisualTransformation {
    override fun filter(text: AnnotatedString): TransformedText =
        TransformedText(JsHighlighter.highlight(text.text, palette, match, errorLine), OffsetMapping.Identity)
}

class EditHistory {
    private val undoStack = ArrayDeque<TextFieldValue>()
    private val redoStack = ArrayDeque<TextFieldValue>()
    private var last = 0L

    /** Gọi trước khi thay đổi nội dung, truyền vào giá trị cũ. Gộp các lần gõ liên tiếp. */
    fun record(old: TextFieldValue) {
        val now = SystemClock.uptimeMillis()
        if (undoStack.isEmpty() || now - last > 700) {
            undoStack.addLast(old)
            if (undoStack.size > 200) undoStack.removeFirst()
        }
        last = now
        redoStack.clear()
    }

    fun undo(current: TextFieldValue): TextFieldValue? {
        if (undoStack.isEmpty()) return null
        redoStack.addLast(current)
        last = 0L
        return undoStack.removeLast()
    }

    fun redo(current: TextFieldValue): TextFieldValue? {
        if (redoStack.isEmpty()) return null
        undoStack.addLast(current)
        last = 0L
        return redoStack.removeLast()
    }
}

object EditorLogic {
    /** Tự thụt lề khi người dùng nhấn Enter. */
    fun autoIndent(old: TextFieldValue, new: TextFieldValue): TextFieldValue {
        val pos = new.selection.start
        val typedEnter = new.text.length == old.text.length + 1 &&
            new.selection.collapsed && old.selection.collapsed &&
            pos > 0 && pos == old.selection.start + 1 && new.text[pos - 1] == '\n'
        if (!typedEnter) return new

        val before = new.text.substring(0, pos - 1)
        val after = new.text.substring(pos)
        val prevLine = before.substring(before.lastIndexOf('\n') + 1)
        val indent = prevLine.takeWhile { it == ' ' || it == '\t' }
        val trimmed = prevLine.trimEnd()
        val extra = if (trimmed.endsWith("{") || trimmed.endsWith("(") || trimmed.endsWith("[")) "  " else ""
        val closes = after.startsWith("}") || after.startsWith(")") || after.startsWith("]")

        return if (extra.isNotEmpty() && closes) {
            val text = before + "\n" + indent + extra + "\n" + indent + after
            TextFieldValue(text, TextRange(before.length + 1 + indent.length + extra.length))
        } else {
            val text = before + "\n" + indent + extra + after
            TextFieldValue(text, TextRange(before.length + 1 + indent.length + extra.length))
        }
    }
}
