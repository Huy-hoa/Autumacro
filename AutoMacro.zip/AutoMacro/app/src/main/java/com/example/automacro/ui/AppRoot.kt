package com.example.automacro.ui

import androidx.activity.compose.BackHandler
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import com.example.automacro.storage.MacroRepository

sealed class Screen {
    object Home : Screen()
    class Editor(val id: String) : Screen()
    object Logs : Screen()
    object Help : Screen()
}

@Composable
fun AppRoot() {
    val ctx = LocalContext.current
    val repo = remember { MacroRepository.get(ctx) }
    var screen by remember { mutableStateOf<Screen>(Screen.Home) }

    BackHandler(enabled = screen != Screen.Home) { screen = Screen.Home }

    when (val s = screen) {
        Screen.Home -> HomeScreen(
            repo = repo,
            onOpen = { screen = Screen.Editor(it) },
            onLogs = { screen = Screen.Logs },
            onHelp = { screen = Screen.Help }
        )
        is Screen.Editor -> EditorScreen(repo, s.id) { screen = Screen.Home }
        Screen.Logs -> LogsScreen { screen = Screen.Home }
        Screen.Help -> HelpScreen { screen = Screen.Home }
    }
}
