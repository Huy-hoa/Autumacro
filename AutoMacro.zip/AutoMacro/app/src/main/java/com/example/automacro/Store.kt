package com.example.automacro

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** type: TAP, SWIPE, WAIT, FIND */
class Step(
    val type: String,
    var x1: Int = 0,
    var y1: Int = 0,
    var x2: Int = 0,
    var y2: Int = 0,
    var ms: Long = 1000L,
    var file: String = "",
    var stop: Boolean = false
) {
    fun toJson(): JSONObject = JSONObject()
        .put("type", type).put("x1", x1).put("y1", y1).put("x2", x2).put("y2", y2)
        .put("ms", ms).put("file", file).put("stop", stop)

    companion object {
        fun fromJson(o: JSONObject) = Step(
            o.getString("type"), o.optInt("x1"), o.optInt("y1"), o.optInt("x2"), o.optInt("y2"),
            o.optLong("ms", 1000L), o.optString("file"), o.optBoolean("stop")
        )
    }
}

object Store {
    private fun dir(ctx: Context, sub: String) = File(ctx.filesDir, sub).apply { mkdirs() }

    fun clean(name: String): String {
        val n = name.trim().replace(Regex("[\\\\/:*?\"<>|]"), "_")
        return if (n.isEmpty()) "macro" else n
    }

    fun templateFile(ctx: Context, file: String) = File(dir(ctx, "templates"), file)

    fun list(ctx: Context): List<String> =
        dir(ctx, "macros").listFiles()?.filter { it.extension == "json" }
            ?.map { it.nameWithoutExtension }?.sorted() ?: emptyList()

    fun save(ctx: Context, name: String, steps: List<Step>) {
        val arr = JSONArray()
        steps.forEach { arr.put(it.toJson()) }
        File(dir(ctx, "macros"), clean(name) + ".json")
            .writeText(JSONObject().put("steps", arr).toString())
    }

    fun load(ctx: Context, name: String): MutableList<Step> {
        val f = File(dir(ctx, "macros"), clean(name) + ".json")
        if (!f.exists()) return mutableListOf()
        return try {
            val arr = JSONObject(f.readText()).getJSONArray("steps")
            MutableList(arr.length()) { Step.fromJson(arr.getJSONObject(it)) }
        } catch (e: Exception) {
            mutableListOf()
        }
    }

    fun delete(ctx: Context, name: String) {
        load(ctx, name).filter { it.type == "FIND" }.forEach { templateFile(ctx, it.file).delete() }
        File(dir(ctx, "macros"), clean(name) + ".json").delete()
    }
}
