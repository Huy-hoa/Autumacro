@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.automacro.ui

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private const val HELP = """HƯỚNG DẪN & API (Giai đoạn 1)

NGÔN NGỮ
Macro viết bằng JavaScript (QuickJS, hỗ trợ ES2020): var/let/const, if/else/switch, for/while/do-while, hàm, đệ quy, mảng, object, JSON...

API ĐÃ CÓ
Log.info(...)   Log.warn(...)   Log.error(...)   Log.debug(...)
  Ghi vào nhật ký. Nhận nhiều tham số; object/mảng được in dạng JSON.
  console.log(...) cũng hoạt động.

Time.delay(ms)      Chờ ms mili giây (có thể dừng giữa chừng).
Time.delaySec(s)    Chờ s giây.
Time.now()          Thời gian hiện tại (ms, giống Date.now()).
Time.elapsed()      Số ms đã chạy kể từ khi macro bắt đầu.

Sys.exit()          Kết thúc macro ngay.

VÍ DỤ
var dem = 0;
while (dem < 5) {
  dem += 1;
  Log.info("Lần", dem);
  Time.delay(1000);
}

LƯU Ý QUAN TRỌNG
• Macro chỉ dừng được tại các lệnh Log.* / Time.* / Sys.*. Vòng lặp không gọi các lệnh này (ví dụ while(true){}) sẽ không dừng được; app sẽ hiện nút "Đóng app". Luôn thêm Time.delay trong vòng lặp dài.
• Chỉ chạy 1 macro tại một thời điểm.
• Macro đang chạy trong chính ứng dụng; nếu hệ thống đóng ứng dụng, macro sẽ dừng.

CHƯA CÓ (các giai đoạn sau)
Touch/Swipe, Screen/Region/Image/Color/OCR, Overlay, Setting, Env, File, tạm dừng/tiếp tục, chạy nền bằng dịch vụ.

QUẢN LÝ FILE
• Xuất macro: menu ⋮ trên thẻ macro > Xuất (.mcr). Tệp .mcr là ZIP gồm manifest.json và main.js.
• Nhập macro: menu ⋮ trên Trang chủ > Nhập macro.
• Thư mục: điền tên thư mục khi tạo hoặc sửa thông tin macro; các thư mục hiện thành bộ lọc.
• Sao lưu / Khôi phục: menu ⋮ trên Trang chủ.

CÔNG CỤ CŨ
Menu ⋮ > Công cụ chạm bằng bảng nổi: bản 2.0 (chạm/vuốt/tìm ảnh bằng bảng nổi) vẫn được giữ nguyên."""

@Composable
fun HelpScreen(onBack: () -> Unit) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Hướng dẫn & API") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Quay lại") } }
            )
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
            Text(HELP, fontFamily = FontFamily.Monospace, fontSize = 13.sp)
        }
    }
}
