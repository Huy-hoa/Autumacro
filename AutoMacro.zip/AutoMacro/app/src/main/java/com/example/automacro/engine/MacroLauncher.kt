package com.example.automacro.engine

import com.example.automacro.logging.LogLevel
import com.example.automacro.logging.LogStore
import com.example.automacro.storage.MacroInfo
import com.example.automacro.storage.MacroRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object MacroLauncher {
    /** Kiểm tra cú pháp rồi chạy. Trả về thông báo lỗi (hoặc null nếu đã chạy). */
    suspend fun launch(repo: MacroRepository, info: MacroInfo, code: String? = null): String? {
        val src = code ?: withContext(Dispatchers.IO) { repo.readCode(info.id) }
        val problem = withContext(Dispatchers.Default) { JsCheck.check(src) }
        if (problem != null) {
            val where = if (problem.line != null) " ở dòng ${problem.line}" else ""
            val msg = "Không chạy được, lỗi cú pháp$where: ${problem.message}"
            LogStore.add(LogLevel.ERROR, msg, info.name)
            return msg
        }
        return if (MacroRuntime.start(info.id, info.name, src)) null else "Đang có macro khác chạy"
    }
}
