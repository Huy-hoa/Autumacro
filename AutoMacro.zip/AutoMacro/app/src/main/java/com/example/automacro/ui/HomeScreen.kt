@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.automacro.ui

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.automacro.AutoClickService
import com.example.automacro.LegacyActivity
import com.example.automacro.engine.MacroLauncher
import com.example.automacro.engine.MacroRuntime
import com.example.automacro.engine.RunState
import com.example.automacro.storage.MacroInfo
import com.example.automacro.storage.MacroRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private sealed class HomeDialog {
    object Create : HomeDialog()
    class Edit(val m: MacroInfo) : HomeDialog()
    class Delete(val m: MacroInfo) : HomeDialog()
    object Restore : HomeDialog()
}

private fun fmtDate(t: Long): String = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("vi")).format(Date(t))

@Composable
fun HomeScreen(repo: MacroRepository, onOpen: (String) -> Unit, onLogs: () -> Unit, onHelp: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val snack = remember { SnackbarHostState() }
    var macros by remember { mutableStateOf(repo.list()) }
    val runState by MacroRuntime.state.collectAsState()
    val activeId by MacroRuntime.activeId.collectAsState()
    var filter by remember { mutableStateOf<String?>(null) }
    var dialog by remember { mutableStateOf<HomeDialog?>(null) }
    var menu by remember { mutableStateOf(false) }
    var exportTarget by remember { mutableStateOf<MacroInfo?>(null) }
    var accOn by remember { mutableStateOf(AutoClickService.instance != null) }

    LaunchedEffect(Unit) {
        while (true) {
            accOn = AutoClickService.instance != null
            delay(1000)
        }
    }

    fun refresh() { macros = repo.list() }
    fun say(msg: String) { scope.launch { snack.showSnackbar(msg) } }

    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/octet-stream")
    ) { uri: Uri? ->
        val t = exportTarget
        if (uri != null && t != null) {
            scope.launch {
                val r = runCatching {
                    withContext(Dispatchers.IO) {
                        ctx.contentResolver.openOutputStream(uri)!!.use { repo.exportMcr(t.id, it) }
                    }
                }
                say(if (r.isSuccess) "Đã xuất: ${t.name}" else "Xuất lỗi: ${r.exceptionOrNull()?.message}")
            }
        }
    }

    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                val r = runCatching {
                    withContext(Dispatchers.IO) {
                        ctx.contentResolver.openInputStream(uri)!!.use { repo.importMcr(it) }
                    }
                }
                val info = r.getOrNull()
                if (info != null) {
                    refresh()
                    say("Đã nhập: ${info.name}")
                } else {
                    say("Nhập lỗi: ${r.exceptionOrNull()?.message}")
                }
            }
        }
    }

    val backupLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/zip")
    ) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                val r = runCatching {
                    withContext(Dispatchers.IO) {
                        ctx.contentResolver.openOutputStream(uri)!!.use { repo.backup(it) }
                    }
                }
                say(if (r.isSuccess) "Đã sao lưu ${r.getOrNull()} macro" else "Sao lưu lỗi: ${r.exceptionOrNull()?.message}")
            }
        }
    }

    val restoreLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                val r = runCatching {
                    withContext(Dispatchers.IO) {
                        ctx.contentResolver.openInputStream(uri)!!.use { repo.restore(it) }
                    }
                }
                refresh()
                val n = r.getOrNull()
                say(if (n != null) "Đã khôi phục $n macro" else "Khôi phục lỗi: ${r.exceptionOrNull()?.message}")
            }
        }
    }

    val folders = macros.map { it.folder }.filter { it.isNotBlank() }.distinct().sorted()
    val activeFilter = filter?.takeIf { it in folders }
    val shown = macros.filter { activeFilter == null || it.folder == activeFilter }
    val activeName = macros.firstOrNull { it.id == activeId }?.name

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("AutoMacro") },
                actions = {
                    IconButton(onClick = { menu = true }) { Icon(Icons.Default.MoreVert, "Menu") }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        DropdownMenuItem(text = { Text("Nhập macro (.mcr)") }, onClick = {
                            menu = false; importLauncher.launch(arrayOf("*/*"))
                        })
                        DropdownMenuItem(text = { Text("Sao lưu tất cả") }, onClick = {
                            menu = false; backupLauncher.launch("automacro-backup.zip")
                        })
                        DropdownMenuItem(text = { Text("Khôi phục từ sao lưu") }, onClick = {
                            menu = false; dialog = HomeDialog.Restore
                        })
                        DropdownMenuItem(text = { Text("Nhật ký hoạt động") }, onClick = { menu = false; onLogs() })
                        DropdownMenuItem(text = { Text("Hướng dẫn & API") }, onClick = { menu = false; onHelp() })
                        DropdownMenuItem(text = { Text("Công cụ chạm bằng bảng nổi (bản cũ)") }, onClick = {
                            menu = false
                            ctx.startActivity(Intent(ctx, LegacyActivity::class.java))
                        })
                    }
                }
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { dialog = HomeDialog.Create },
                icon = { Icon(Icons.Default.Add, null) },
                text = { Text("Tạo macro") }
            )
        },
        snackbarHost = { SnackbarHost(snack) }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            UnresponsiveBanner()
            LazyColumn(
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(12.dp, 12.dp, 12.dp, 88.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    StatusCard(runState, activeName, accOn) {
                        ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                    }
                }
                if (folders.isNotEmpty()) {
                    item {
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilterChip(selected = activeFilter == null, onClick = { filter = null }, label = { Text("Tất cả") })
                            folders.forEach { f ->
                                FilterChip(selected = activeFilter == f, onClick = { filter = f }, label = { Text(f) })
                            }
                        }
                    }
                }
                if (shown.isEmpty()) {
                    item {
                        Text(
                            "Chưa có macro nào. Bấm “Tạo macro” hoặc nhập tệp .mcr từ menu ⋮.",
                            modifier = Modifier.padding(16.dp),
                            color = MaterialTheme.colorScheme.outline
                        )
                    }
                }
                items(shown, key = { it.id }) { m ->
                    MacroCard(
                        m = m,
                        isActive = m.id == activeId,
                        runState = runState,
                        onRun = {
                            scope.launch {
                                val err = MacroLauncher.launch(repo, m)
                                if (err != null) snack.showSnackbar(err)
                            }
                        },
                        onStop = { MacroRuntime.stop() },
                        onEdit = { onOpen(m.id) },
                        onInfo = { dialog = HomeDialog.Edit(m) },
                        onDup = { repo.duplicate(m.id); refresh() },
                        onExport = {
                            exportTarget = m
                            exportLauncher.launch(m.name + ".mcr")
                        },
                        onDelete = { dialog = HomeDialog.Delete(m) }
                    )
                }
            }
        }
    }

    when (val d = dialog) {
        null -> {}
        HomeDialog.Create -> InfoDialog(
            title = "Tạo macro mới",
            initial = null,
            onDismiss = { dialog = null },
            onSave = { n, desc, folder, _ ->
                val m = repo.create(n, desc, folder)
                dialog = null
                refresh()
                onOpen(m.id)
            }
        )
        is HomeDialog.Edit -> InfoDialog(
            title = "Thông tin macro",
            initial = d.m,
            onDismiss = { dialog = null },
            onSave = { n, desc, folder, ver ->
                repo.update(d.m.id, n, desc, folder, ver)
                dialog = null
                refresh()
            }
        )
        is HomeDialog.Delete -> AlertDialog(
            onDismissRequest = { dialog = null },
            title = { Text("Xóa macro?") },
            text = { Text("Macro “${d.m.name}” sẽ bị xóa vĩnh viễn.") },
            confirmButton = {
                TextButton(onClick = {
                    if (activeId == d.m.id) MacroRuntime.stop()
                    repo.delete(d.m.id)
                    dialog = null
                    refresh()
                }) { Text("Xóa") }
            },
            dismissButton = { TextButton(onClick = { dialog = null }) { Text("Hủy") } }
        )
        HomeDialog.Restore -> AlertDialog(
            onDismissRequest = { dialog = null },
            title = { Text("Khôi phục từ sao lưu") },
            text = { Text("Các macro trong tệp sao lưu sẽ được khôi phục. Macro hiện có cùng mã sẽ bị ghi đè.") },
            confirmButton = {
                TextButton(onClick = {
                    dialog = null
                    restoreLauncher.launch(arrayOf("*/*"))
                }) { Text("Chọn tệp") }
            },
            dismissButton = { TextButton(onClick = { dialog = null }) { Text("Hủy") } }
        )
    }
}

@Composable
private fun StatusCard(runState: RunState, activeName: String?, accOn: Boolean, onAcc: () -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp)) {
            val st = when (runState) {
                RunState.IDLE -> "Rảnh"
                RunState.RUNNING -> "Đang chạy · ${activeName ?: ""}"
                RunState.STOPPING -> "Đang dừng..."
            }
            Text("Bộ chạy macro: $st", fontWeight = FontWeight.Medium)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "Dịch vụ trợ năng: " + if (accOn) "Đã bật" else "Chưa bật",
                    modifier = Modifier.weight(1f),
                    fontSize = 13.sp
                )
                if (!accOn) TextButton(onClick = onAcc) { Text("Bật") }
            }
            Text(
                "Dịch vụ trợ năng chưa cần cho macro JS ở giai đoạn 1; chỉ cần cho công cụ chạm bảng nổi và các API chạm ở giai đoạn 3.",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.outline
            )
        }
    }
}

@Composable
private fun MacroCard(
    m: MacroInfo,
    isActive: Boolean,
    runState: RunState,
    onRun: () -> Unit,
    onStop: () -> Unit,
    onEdit: () -> Unit,
    onInfo: () -> Unit,
    onDup: () -> Unit,
    onExport: () -> Unit,
    onDelete: () -> Unit
) {
    var menu by remember { mutableStateOf(false) }
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(m.name, fontWeight = FontWeight.Bold, fontSize = 16.sp, modifier = Modifier.weight(1f))
                Text(
                    if (isActive) (if (runState == RunState.STOPPING) "Đang dừng" else "Đang chạy") else "Sẵn sàng",
                    color = if (isActive) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline,
                    fontSize = 12.sp
                )
            }
            if (m.description.isNotBlank()) Text(m.description, fontSize = 13.sp)
            Text(
                "v${m.version}" + (if (m.folder.isNotBlank()) " · ${m.folder}" else "") + " · ${fmtDate(m.modifiedAt)}",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.outline
            )
            Row(
                Modifier.padding(top = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (isActive) {
                    FilledTonalButton(onClick = onStop, enabled = runState == RunState.RUNNING) { Text("Dừng") }
                } else {
                    Button(onClick = onRun, enabled = runState == RunState.IDLE) { Text("Chạy") }
                }
                OutlinedButton(onClick = onEdit) { Text("Sửa") }
                Spacer(Modifier.weight(1f))
                Box {
                    IconButton(onClick = { menu = true }) { Icon(Icons.Default.MoreVert, "Thêm") }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        DropdownMenuItem(text = { Text("Sửa thông tin / thư mục") }, onClick = { menu = false; onInfo() })
                        DropdownMenuItem(text = { Text("Sao chép") }, onClick = { menu = false; onDup() })
                        DropdownMenuItem(text = { Text("Xuất (.mcr)") }, onClick = { menu = false; onExport() })
                        DropdownMenuItem(text = { Text("Xóa") }, onClick = { menu = false; onDelete() })
                    }
                }
            }
        }
    }
}

@Composable
private fun InfoDialog(
    title: String,
    initial: MacroInfo?,
    onDismiss: () -> Unit,
    onSave: (String, String, String, Int) -> Unit
) {
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var desc by remember { mutableStateOf(initial?.description ?: "") }
    var folder by remember { mutableStateOf(initial?.folder ?: "") }
    var version by remember { mutableStateOf((initial?.version ?: 1).toString()) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Tên macro") }, singleLine = true)
                OutlinedTextField(value = desc, onValueChange = { desc = it }, label = { Text("Mô tả") })
                OutlinedTextField(
                    value = folder, onValueChange = { folder = it },
                    label = { Text("Thư mục (để trống = gốc)") }, singleLine = true
                )
                if (initial != null) {
                    OutlinedTextField(value = version, onValueChange = { version = it }, label = { Text("Phiên bản") }, singleLine = true)
                }
            }
        },
        confirmButton = {
            TextButton(
                onClick = { onSave(name.trim(), desc.trim(), folder.trim(), version.toIntOrNull() ?: 1) },
                enabled = name.isNotBlank()
            ) { Text("Lưu") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Hủy") } }
    )
}
