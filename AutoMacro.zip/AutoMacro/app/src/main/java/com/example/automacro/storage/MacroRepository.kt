package com.example.automacro.storage

import android.content.Context
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.util.UUID
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

data class MacroInfo(
    val id: String,
    val name: String,
    val description: String,
    val version: Int,
    val author: String,
    val folder: String,
    val createdAt: Long,
    val modifiedAt: Long
)

/**
 * Mỗi macro là một thư mục: manifest.json + main.js (+ images/ ở giai đoạn sau).
 * Tệp .mcr là ZIP của đúng thư mục đó.
 */
class MacroRepository private constructor(private val root: File) {

    companion object {
        const val FORMAT_VERSION = 1
        private const val MAX_TOTAL = 100L * 1024 * 1024

        const val DEFAULT_CODE = """// Macro mới
Log.info("Xin chào!");
for (var i = 1; i <= 3; i++) {
  Log.info("Vòng " + i);
  Time.delay(500);
}
Log.info("Xong.");
"""

        @Volatile private var inst: MacroRepository? = null

        fun get(ctx: Context): MacroRepository =
            inst ?: synchronized(this) {
                inst ?: MacroRepository(File(ctx.applicationContext.filesDir, "macros_v3").apply { mkdirs() })
                    .also { inst = it }
            }
    }

    private fun dir(id: String) = File(root, id)

    private fun atomicWrite(f: File, text: String) {
        val tmp = File(f.parentFile, f.name + ".tmp")
        tmp.writeText(text)
        if (!tmp.renameTo(f)) {
            f.writeText(text)
            tmp.delete()
        }
    }

    private fun readInfo(d: File): MacroInfo? = try {
        val o = JSONObject(File(d, "manifest.json").readText())
        MacroInfo(
            id = d.name,
            name = o.optString("name", "Macro").ifBlank { "Macro" },
            description = o.optString("description", ""),
            version = o.optInt("version", 1),
            author = o.optString("author", ""),
            folder = o.optString("folder", ""),
            createdAt = o.optLong("createdAt", 0L),
            modifiedAt = o.optLong("modifiedAt", 0L)
        )
    } catch (e: Exception) {
        null
    }

    private fun writeInfo(i: MacroInfo) {
        val o = JSONObject()
            .put("format", "mcr")
            .put("formatVersion", FORMAT_VERSION)
            .put("id", i.id)
            .put("name", i.name)
            .put("description", i.description)
            .put("version", i.version)
            .put("author", i.author)
            .put("folder", i.folder)
            .put("createdAt", i.createdAt)
            .put("modifiedAt", i.modifiedAt)
            .put("entry", "main.js")
        atomicWrite(File(dir(i.id), "manifest.json"), o.toString(2))
    }

    fun list(): List<MacroInfo> =
        (root.listFiles() ?: emptyArray())
            .filter { it.isDirectory && !it.name.startsWith(".") }
            .mapNotNull { readInfo(it) }
            .sortedByDescending { it.modifiedAt }

    fun get(id: String): MacroInfo? = if (dir(id).isDirectory) readInfo(dir(id)) else null

    @Synchronized
    fun create(name: String, description: String, folder: String, code: String = DEFAULT_CODE): MacroInfo {
        val id = UUID.randomUUID().toString()
        val now = System.currentTimeMillis()
        val info = MacroInfo(id, name.ifBlank { "Macro mới" }, description, 1, "", folder.trim(), now, now)
        dir(id).mkdirs()
        atomicWrite(File(dir(id), "main.js"), code)
        writeInfo(info)
        return info
    }

    fun readCode(id: String): String = try { File(dir(id), "main.js").readText() } catch (e: Exception) { "" }

    @Synchronized
    fun writeCode(id: String, code: String) {
        if (!dir(id).isDirectory) return
        val f = File(dir(id), "main.js")
        if (f.exists() && f.readText() == code) return
        atomicWrite(f, code)
        readInfo(dir(id))?.let { writeInfo(it.copy(modifiedAt = System.currentTimeMillis())) }
    }

    @Synchronized
    fun update(id: String, name: String, description: String, folder: String, version: Int) {
        val i = readInfo(dir(id)) ?: return
        writeInfo(
            i.copy(
                name = name.ifBlank { i.name },
                description = description,
                folder = folder.trim(),
                version = version.coerceAtLeast(1),
                modifiedAt = System.currentTimeMillis()
            )
        )
    }

    @Synchronized
    fun duplicate(id: String): MacroInfo? {
        val src = readInfo(dir(id)) ?: return null
        val newId = UUID.randomUUID().toString()
        dir(id).copyRecursively(dir(newId), overwrite = false)
        val now = System.currentTimeMillis()
        val copy = src.copy(id = newId, name = src.name + " (bản sao)", createdAt = now, modifiedAt = now)
        writeInfo(copy)
        return copy
    }

    @Synchronized
    fun delete(id: String) { dir(id).deleteRecursively() }

    // ---------- .mcr ----------

    private fun addDir(zip: ZipOutputStream, base: File, prefix: String) {
        base.listFiles()?.sortedBy { it.name }?.forEach { f ->
            if (f.name.endsWith(".tmp")) return@forEach
            if (f.isDirectory) {
                addDir(zip, f, prefix + f.name + "/")
            } else {
                zip.putNextEntry(ZipEntry(prefix + f.name))
                f.inputStream().use { it.copyTo(zip) }
                zip.closeEntry()
            }
        }
    }

    fun exportMcr(id: String, out: OutputStream) {
        if (!dir(id).isDirectory) throw IOException("Không tìm thấy macro")
        ZipOutputStream(out).use { zip -> addDir(zip, dir(id), "") }
    }

    private fun extractZip(input: InputStream, target: File) {
        val base = target.canonicalPath + File.separator
        var total = 0L
        val buf = ByteArray(8192)
        ZipInputStream(input).use { zin ->
            var e = zin.nextEntry
            while (e != null) {
                val out = File(target, e.name).canonicalFile
                if (!out.path.startsWith(base)) throw SecurityException("Tệp nén chứa đường dẫn không an toàn")
                if (e.isDirectory) {
                    out.mkdirs()
                } else {
                    out.parentFile?.mkdirs()
                    out.outputStream().use { os ->
                        while (true) {
                            val n = zin.read(buf)
                            if (n < 0) break
                            total += n
                            if (total > MAX_TOTAL) throw IOException("Tệp quá lớn")
                            os.write(buf, 0, n)
                        }
                    }
                }
                zin.closeEntry()
                e = zin.nextEntry
            }
        }
    }

    @Synchronized
    fun importMcr(input: InputStream): MacroInfo {
        val tmp = File(root, ".import_" + UUID.randomUUID()).apply { mkdirs() }
        try {
            try {
                extractZip(input, tmp)
            } catch (e: java.util.zip.ZipException) {
                throw IllegalArgumentException("Tệp không phải .mcr hợp lệ (không đọc được ZIP)")
            }
            val mf = File(tmp, "manifest.json")
            val cf = File(tmp, "main.js")
            if (!mf.exists() || !cf.exists()) {
                throw IllegalArgumentException("Tệp .mcr lỗi: thiếu manifest.json hoặc main.js")
            }
            val o = try { JSONObject(mf.readText()) } catch (e: Exception) {
                throw IllegalArgumentException("Tệp .mcr lỗi: manifest.json không đọc được")
            }
            if (o.optString("format") != "mcr") throw IllegalArgumentException("Tệp .mcr lỗi: sai định dạng")
            val ver = o.optInt("formatVersion", 0)
            if (ver < 1 || ver > FORMAT_VERSION) {
                throw IllegalArgumentException("Phiên bản định dạng $ver chưa được hỗ trợ")
            }
            val id = UUID.randomUUID().toString()
            val now = System.currentTimeMillis()
            val info = MacroInfo(
                id = id,
                name = o.optString("name", "Macro đã nhập").ifBlank { "Macro đã nhập" },
                description = o.optString("description", ""),
                version = o.optInt("version", 1),
                author = o.optString("author", ""),
                folder = o.optString("folder", ""),
                createdAt = o.optLong("createdAt", now),
                modifiedAt = now
            )
            if (!tmp.renameTo(dir(id))) throw IOException("Không tạo được macro")
            writeInfo(info)
            return info
        } catch (e: Throwable) {
            tmp.deleteRecursively()
            throw e
        }
    }

    // ---------- Sao lưu / khôi phục ----------

    fun backup(out: OutputStream): Int {
        var n = 0
        ZipOutputStream(out).use { zip ->
            (root.listFiles() ?: emptyArray())
                .filter { it.isDirectory && !it.name.startsWith(".") }
                .forEach { d ->
                    if (readInfo(d) != null) {
                        addDir(zip, d, "macros/${d.name}/")
                        n++
                    }
                }
        }
        return n
    }

    @Synchronized
    fun restore(input: InputStream): Int {
        val tmp = File(root, ".restore_" + UUID.randomUUID()).apply { mkdirs() }
        try {
            try {
                extractZip(input, tmp)
            } catch (e: java.util.zip.ZipException) {
                throw IllegalArgumentException("Tệp sao lưu không hợp lệ")
            }
            val dirs = File(tmp, "macros").listFiles()?.filter { it.isDirectory }
                ?: throw IllegalArgumentException("Tệp sao lưu không hợp lệ (không có thư mục macros)")
            var count = 0
            for (d in dirs) {
                if (!File(d, "main.js").exists() || readInfo(d) == null) continue
                if (!Regex("[A-Za-z0-9-]{1,64}").matches(d.name)) continue
                val target = dir(d.name)
                target.deleteRecursively()
                if (d.renameTo(target)) count++
            }
            return count
        } finally {
            tmp.deleteRecursively()
        }
    }
}
