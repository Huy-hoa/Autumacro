package com.example.automacro.logging

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class LogLevel(val tag: String) { INFO("INFO"), WARN("CẢNH BÁO"), ERROR("LỖI"), DEBUG("DEBUG") }

data class LogEntry(val time: Long, val level: LogLevel, val msg: String, val source: String)

object LogStore {
    private const val MAX = 2000
    private val _entries = MutableStateFlow<List<LogEntry>>(emptyList())
    val entries: StateFlow<List<LogEntry>> = _entries

    fun add(level: LogLevel, msg: String, source: String = "") {
        val e = LogEntry(System.currentTimeMillis(), level, msg, source)
        _entries.update { (it + e).takeLast(MAX) }
    }

    fun clear() { _entries.value = emptyList() }

    fun timeText(t: Long): String = SimpleDateFormat("HH:mm:ss.SSS", Locale.US).format(Date(t))

    fun asText(): String = _entries.value.joinToString("\n") { e ->
        val src = if (e.source.isEmpty()) "" else " [${e.source}]"
        "${timeText(e.time)} ${e.level.tag}$src ${e.msg}"
    }
}
