package com.example.automacro

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.SystemClock
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.FileOutputStream
import kotlin.coroutines.resume
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class AutoClickService : AccessibilityService() {

    companion object {
        var instance: AutoClickService? = null
        private val WAIT_OPTIONS = longArrayOf(500, 1000, 2000, 3000, 5000, 10000)
        private const val MATCH_THRESHOLD = 0.90f
        private const val FIND_TIMEOUT_MS = 3000L
    }

    private class Ov(val view: View, val lp: WindowManager.LayoutParams)
    private class Node(val step: Step, val ovs: List<Ov>)

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val wm by lazy { getSystemService(WINDOW_SERVICE) as WindowManager }
    private val nodes = mutableListOf<Node>()
    private var bar: Ov? = null
    private var stopOv: Ov? = null
    private var pending: Ov? = null
    private var job: Job? = null
    private var current: String? = null

    private val density: Float get() = resources.displayMetrics.density
    private fun dp(v: Int) = (v * density).toInt()
    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()

    override fun onServiceConnected() { instance = this }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onDestroy() {
        closeAll()
        scope.cancel()
        instance = null
        super.onDestroy()
    }

    // ================= API cho MainActivity =================

    fun openMacro(name: String) {
        val n = Store.clean(name)
        stopRun()
        clearNodes()
        current = n
        showBar()
        Store.load(this, n).forEach { addNode(it) }
        toast("Đang mở macro: $n")
    }

    // ================= Cửa sổ nổi =================

    private fun params(touchable: Boolean) = WindowManager.LayoutParams(
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
            (if (touchable) 0 else WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE),
        PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.START }

    private fun removeOv(o: Ov?) {
        if (o != null) runCatching { wm.removeView(o.view) }
    }

    private fun setTouchable(o: Ov, touchable: Boolean) {
        o.lp.flags = if (touchable) {
            o.lp.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
        } else {
            o.lp.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        }
        runCatching { wm.updateViewLayout(o.view, o.lp) }
    }

    private fun attachDrag(
        touch: View, lp: WindowManager.LayoutParams, target: View, onClick: (() -> Unit)? = null
    ) {
        var sx = 0
        var sy = 0
        var tx = 0f
        var ty = 0f
        var moved = false
        val slop = dp(8)
        touch.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY; moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - tx
                    val dy = e.rawY - ty
                    if (abs(dx) > slop || abs(dy) > slop) moved = true
                    if (moved) {
                        lp.x = sx + dx.toInt()
                        lp.y = sy + dy.toInt()
                        wm.updateViewLayout(target, lp)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) onClick?.invoke()
                }
            }
            true
        }
    }

    private fun circle(label: String, color: Int, cx: Int, cy: Int): Ov {
        val size = dp(44)
        val tv = TextView(this).apply {
            text = label
            textSize = 13f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(color)
                setStroke(dp(2), Color.WHITE)
            }
        }
        val lp = params(true).apply {
            width = size
            height = size
            x = cx - size / 2
            y = cy - size / 2
        }
        attachDrag(tv, lp, tv)
        wm.addView(tv, lp)
        return Ov(tv, lp)
    }

    private fun chip(label: String, color: Int, px: Int, py: Int, onClick: (TextView) -> Unit): Ov {
        val tv = TextView(this).apply {
            text = label
            textSize = 13f
            setTextColor(Color.WHITE)
            setPadding(dp(10), dp(6), dp(10), dp(6))
            background = GradientDrawable().apply {
                cornerRadius = dp(16).toFloat()
                setColor(color)
            }
        }
        val lp = params(true).apply { x = px; y = py }
        attachDrag(tv, lp, tv) { onClick(tv) }
        wm.addView(tv, lp)
        return Ov(tv, lp)
    }

    // ================= Thanh điều khiển =================

    private fun showBar() {
        if (bar != null) return
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xE6222222.toInt())
            setPadding(dp(4), dp(4), dp(4), dp(4))
        }
        val row1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val row2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }

        val handle = TextView(this).apply {
            text = "☰"
            textSize = 20f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(dp(10), 0, dp(10), 0)
        }

        fun btn(t: String, f: () -> Unit) = Button(this).apply {
            text = t
            isAllCaps = false
            textSize = 12f
            minWidth = 0
            minimumWidth = 0
            minHeight = 0
            minimumHeight = 0
            setPadding(dp(8), dp(6), dp(8), dp(6))
            setOnClickListener { f() }
        }

        row1.addView(handle)
        row1.addView(btn("Chạm") { addNode(newStep("TAP")) })
        row1.addView(btn("Vuốt") { addNode(newStep("SWIPE")) })
        row1.addView(btn("Ảnh") { startCapture() })
        row1.addView(btn("Chờ") { addNode(newStep("WAIT")) })
        row2.addView(btn("Xóa cuối") { removeLast() })
        row2.addView(btn("▶ Chạy") { startRun() })
        row2.addView(btn("Lưu") { saveCurrent(); toast("Đã lưu") })
        row2.addView(btn("Đóng") { saveCurrent(); closeAll() })
        root.addView(row1, ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        root.addView(row2, ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)

        val lp = params(true).apply { x = dp(8); y = dp(100) }
        attachDrag(handle, lp, root)
        wm.addView(root, lp)
        bar = Ov(root, lp)
    }

    // ================= Các bước =================

    private fun newStep(type: String): Step {
        val dm = resources.displayMetrics
        val off = (nodes.size % 6) * dp(14)
        val cx = dm.widthPixels / 2 + off
        val cy = dm.heightPixels / 2 + off
        return when (type) {
            "TAP" -> Step("TAP", x1 = cx, y1 = cy)
            "SWIPE" -> Step("SWIPE", x1 = cx, y1 = cy + dp(120), x2 = cx, y2 = cy - dp(120))
            else -> Step("WAIT", x1 = dp(16), y1 = dp(220) + (nodes.size % 8) * dp(40), ms = 1000L)
        }
    }

    private fun secs(ms: Long) = "${ms / 1000.0}s"

    private fun findLabel(n: Int, step: Step) =
        "$n. Ảnh · thiếu: ${if (step.stop) "dừng" else "bỏ qua"}"

    private fun addNode(step: Step) {
        val n = nodes.size + 1
        val ovs: List<Ov> = when (step.type) {
            "TAP" -> listOf(circle("$n", 0xCCE53935.toInt(), step.x1, step.y1))
            "SWIPE" -> listOf(
                circle("$n", 0xCC2E7D32.toInt(), step.x1, step.y1),
                circle("$n→", 0xCC1565C0.toInt(), step.x2, step.y2)
            )
            "WAIT" -> listOf(
                chip("$n. Chờ ${secs(step.ms)}", 0xCC455A64.toInt(), step.x1, step.y1) { tv ->
                    val i = WAIT_OPTIONS.indexOf(step.ms)
                    step.ms = WAIT_OPTIONS[(i + 1) % WAIT_OPTIONS.size]
                    tv.text = "$n. Chờ ${secs(step.ms)}"
                }
            )
            else -> listOf(
                chip(findLabel(n, step), 0xCCEF6C00.toInt(), step.x1, step.y1) { tv ->
                    step.stop = !step.stop
                    tv.text = findLabel(n, step)
                }
            )
        }
        nodes.add(Node(step, ovs))
    }

    private fun removeLast() {
        if (pending != null) {
            removeOv(pending)
            pending = null
            return
        }
        if (nodes.isEmpty()) return
        val n = nodes.removeAt(nodes.lastIndex)
        n.ovs.forEach { removeOv(it) }
        if (n.step.type == "FIND") Store.templateFile(this, n.step.file).delete()
    }

    private fun clearNodes() {
        removeOv(pending)
        pending = null
        nodes.forEach { n -> n.ovs.forEach { removeOv(it) } }
        nodes.clear()
    }

    private fun closeAll() {
        stopRun()
        clearNodes()
        removeOv(bar)
        bar = null
        current = null
    }

    private fun center(o: Ov): Pair<Int, Int> {
        val loc = IntArray(2)
        o.view.getLocationOnScreen(loc)
        return Pair(loc[0] + o.lp.width / 2, loc[1] + o.lp.height / 2)
    }

    private fun syncPositions() {
        for (n in nodes) {
            val s = n.step
            when (s.type) {
                "TAP" -> {
                    val c = center(n.ovs[0]); s.x1 = c.first; s.y1 = c.second
                }
                "SWIPE" -> {
                    val a = center(n.ovs[0]); val b = center(n.ovs[1])
                    s.x1 = a.first; s.y1 = a.second; s.x2 = b.first; s.y2 = b.second
                }
                else -> {
                    val loc = IntArray(2)
                    n.ovs[0].view.getLocationOnScreen(loc)
                    s.x1 = loc[0]; s.y1 = loc[1]
                }
            }
        }
    }

    private fun saveCurrent() {
        val name = current ?: return
        syncPositions()
        Store.save(this, name, nodes.map { it.step })
    }

    // ================= Chọn vùng ảnh mẫu =================

    private fun startCapture() {
        if (pending != null) return
        if (Build.VERSION.SDK_INT < 30) {
            toast("Nhận diện hình ảnh cần Android 11 trở lên")
            return
        }
        val dm = resources.displayMetrics
        val frame = FrameLayout(this).apply {
            background = GradientDrawable().apply {
                setColor(0x33FFEB3B)
                setStroke(dp(2), 0xFFFFC107.toInt())
            }
        }
        fun corner(label: String, color: Int, g: Int) = TextView(this).apply {
            text = label
            textSize = 13f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setBackgroundColor(color)
            layoutParams = FrameLayout.LayoutParams(dp(40), dp(40), g)
        }
        val hint = TextView(this).apply {
            text = "Phủ lên vật cần tìm"
            textSize = 11f
            setTextColor(Color.BLACK)
            gravity = Gravity.CENTER
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER
            )
        }
        val ok = corner("OK", 0xFF2E7D32.toInt(), Gravity.TOP or Gravity.END)
        val no = corner("X", 0xFFC62828.toInt(), Gravity.TOP or Gravity.START)
        val grip = corner("↘", 0xFF455A64.toInt(), Gravity.BOTTOM or Gravity.END)
        frame.addView(hint)
        frame.addView(ok)
        frame.addView(no)
        frame.addView(grip)

        val lp = params(true).apply {
            width = dp(170)
            height = dp(100)
            x = (dm.widthPixels - dp(170)) / 2
            y = (dm.heightPixels - dp(100)) / 2
        }
        var w0 = 0
        var h0 = 0
        var gx = 0f
        var gy = 0f
        grip.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    w0 = lp.width; h0 = lp.height; gx = e.rawX; gy = e.rawY
                }
                MotionEvent.ACTION_MOVE -> {
                    lp.width = max(dp(48), w0 + (e.rawX - gx).toInt())
                    lp.height = max(dp(48), h0 + (e.rawY - gy).toInt())
                    wm.updateViewLayout(frame, lp)
                }
            }
            true
        }
        attachDrag(frame, lp, frame)
        wm.addView(frame, lp)
        val ov = Ov(frame, lp)
        pending = ov
        no.setOnClickListener { removeOv(pending); pending = null }
        ok.setOnClickListener { doCapture(ov) }
    }

    private fun setShot(hide: Boolean) {
        val v = if (hide) View.INVISIBLE else View.VISIBLE
        bar?.view?.visibility = v
        pending?.view?.visibility = v
        nodes.forEach { n -> n.ovs.forEach { it.view.visibility = v } }
    }

    private fun doCapture(ov: Ov) {
        val loc = IntArray(2)
        ov.view.getLocationOnScreen(loc)
        val rw = ov.view.width
        val rh = ov.view.height
        setShot(true)
        scope.launch {
            delay(300)
            val bmp = screenshot()
            setShot(false)
            if (bmp == null) {
                toast("Không chụp được màn hình")
                return@launch
            }
            val x = loc[0].coerceIn(0, bmp.width - 1)
            val y = loc[1].coerceIn(0, bmp.height - 1)
            val w = min(rw, bmp.width - x)
            val h = min(rh, bmp.height - y)
            if (w < 16 || h < 16) {
                toast("Vùng chọn quá nhỏ")
                return@launch
            }
            val crop = Bitmap.createBitmap(bmp, x, y, w, h)
            if (Matcher.stdDev(crop) < 12.0) {
                toast("Vùng này quá đơn sắc, hãy chọn vùng có chữ hoặc biểu tượng")
                return@launch
            }
            val name = "t_${System.currentTimeMillis()}.png"
            FileOutputStream(Store.templateFile(this@AutoClickService, name)).use {
                crop.compress(Bitmap.CompressFormat.PNG, 100, it)
            }
            removeOv(pending)
            pending = null
            addNode(Step("FIND", x1 = x, y1 = y, x2 = w, y2 = h, file = name))
            toast("Đã lưu ảnh mẫu")
        }
    }

    // ================= Chạy macro =================

    private fun startRun() {
        if (job != null) return
        if (nodes.isEmpty()) {
            toast("Chưa có bước nào")
            return
        }
        removeOv(pending)
        pending = null
        syncPositions()
        val steps = nodes.map { it.step }
        val prefs = getSharedPreferences("cfg", MODE_PRIVATE)
        val interval = prefs.getLong("interval", 800L).coerceAtLeast(50L)
        val loops = prefs.getInt("loops", 0)
        val tpls = HashMap<String, Bitmap>()
        for (s in steps) {
            if (s.type == "FIND") {
                BitmapFactory.decodeFile(Store.templateFile(this, s.file).path)?.let { tpls[s.file] = it }
            }
        }
        setRunning(true)
        job = scope.launch {
            var n = 0
            var abort = false
            while (isActive && !abort && (loops == 0 || n < loops)) {
                for (s in steps) {
                    when (s.type) {
                        "TAP" -> { tap(s.x1.toFloat(), s.y1.toFloat()); delay(interval) }
                        "SWIPE" -> { swipe(s); delay(interval) }
                        "WAIT" -> delay(s.ms)
                        "FIND" -> {
                            val found = findAndTap(tpls[s.file])
                            if (!found && s.stop) {
                                abort = true
                                toast("Dừng: không thấy ảnh mẫu")
                            }
                            delay(interval)
                        }
                    }
                    if (abort) break
                }
                n++
            }
            stopRun()
        }
    }

    private fun stopRun() {
        val was = job != null
        job?.cancel()
        job = null
        if (was && bar != null) setRunning(false)
    }

    private fun setRunning(on: Boolean) {
        val v = if (on) View.INVISIBLE else View.VISIBLE
        bar?.let {
            it.view.visibility = v
            setTouchable(it, !on)
        }
        nodes.forEach { n ->
            n.ovs.forEach {
                it.view.visibility = v
                setTouchable(it, !on)
            }
        }
        if (on) {
            val b = bar ?: return
            val tv = TextView(this).apply {
                text = "■ Dừng"
                textSize = 14f
                setTextColor(Color.WHITE)
                setPadding(dp(14), dp(10), dp(14), dp(10))
                background = GradientDrawable().apply {
                    cornerRadius = dp(20).toFloat()
                    setColor(0xEEC62828.toInt())
                }
            }
            val lp = params(true).apply { x = b.lp.x; y = b.lp.y }
            attachDrag(tv, lp, tv) { stopRun() }
            wm.addView(tv, lp)
            stopOv = Ov(tv, lp)
        } else {
            removeOv(stopOv)
            stopOv = null
        }
    }

    private suspend fun findAndTap(tpl: Bitmap?): Boolean {
        if (tpl == null) return false
        val deadline = SystemClock.uptimeMillis() + FIND_TIMEOUT_MS
        while (SystemClock.uptimeMillis() < deadline) {
            val shot = screenshot()
            if (shot != null) {
                val hit = withContext(Dispatchers.Default) { Matcher.find(shot, tpl) }
                shot.recycle()
                if (hit != null && hit.score >= MATCH_THRESHOLD) {
                    tap(hit.cx.toFloat(), hit.cy.toFloat())
                    return true
                }
            }
            delay(400)
        }
        return false
    }

    // ================= Thao tác cấp thấp =================

    private suspend fun gesture(path: Path, dur: Long) = suspendCancellableCoroutine<Unit> { c ->
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, dur))
            .build()
        val cb = object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(d: GestureDescription?) { if (c.isActive) c.resume(Unit) }
            override fun onCancelled(d: GestureDescription?) { if (c.isActive) c.resume(Unit) }
        }
        if (!dispatchGesture(g, cb, null) && c.isActive) c.resume(Unit)
    }

    private suspend fun tap(x: Float, y: Float) = gesture(Path().apply { moveTo(x, y) }, 50)

    private suspend fun swipe(s: Step) = gesture(
        Path().apply {
            moveTo(s.x1.toFloat(), s.y1.toFloat())
            lineTo(s.x2.toFloat(), s.y2.toFloat())
        }, 350
    )

    private suspend fun screenshot(): Bitmap? = suspendCancellableCoroutine { c ->
        if (Build.VERSION.SDK_INT < 30) {
            c.resume(null)
            return@suspendCancellableCoroutine
        }
        takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : AccessibilityService.TakeScreenshotCallback {
            override fun onSuccess(result: AccessibilityService.ScreenshotResult) {
                val hb = result.hardwareBuffer
                val hw = Bitmap.wrapHardwareBuffer(hb, result.colorSpace)
                val bmp = hw?.copy(Bitmap.Config.ARGB_8888, false)
                hw?.recycle()
                hb.close()
                if (c.isActive) c.resume(bmp)
            }

            override fun onFailure(errorCode: Int) {
                if (c.isActive) c.resume(null)
            }
        })
    }
}
