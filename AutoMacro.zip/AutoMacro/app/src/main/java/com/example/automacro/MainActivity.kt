package com.example.automacro

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var list: LinearLayout
    private lateinit var nameInput: EditText
    private lateinit var interval: EditText
    private lateinit var loops: EditText

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("cfg", MODE_PRIVATE)
        val pad = dp(16)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }

        root.addView(TextView(this).apply {
            text = "AutoMacro 2.0\n\n" +
                "• Bật dịch vụ trợ năng cho AutoMacro.\n" +
                "• Tạo hoặc mở macro. Trên bảng nổi: Chạm / Vuốt / Ảnh / Chờ để thêm bước, kéo các nút tròn vào đúng vị trí.\n" +
                "• 'Ảnh': phủ khung vàng lên nút cần tìm rồi bấm OK. App sẽ tự tìm ảnh đó trên màn hình và chạm vào (cần Android 11+).\n" +
                "• Chạm vào nhãn 'Chờ' hoặc 'Ảnh' để đổi thời gian chờ / hành vi khi không thấy ảnh.\n" +
                "• Bấm ▶ Chạy để bắt đầu, bấm ■ Dừng để dừng."
        })

        interval = EditText(this).apply {
            hint = "Khoảng nghỉ giữa các bước (ms)"
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(prefs.getLong("interval", 800L).toString())
        }
        loops = EditText(this).apply {
            hint = "Số vòng lặp (0 = vô hạn)"
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(prefs.getInt("loops", 0).toString())
        }
        root.addView(interval)
        root.addView(loops)

        root.addView(Button(this).apply {
            text = "1. Bật dịch vụ trợ năng"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })

        nameInput = EditText(this).apply { hint = "Tên macro mới" }
        root.addView(nameInput)
        root.addView(Button(this).apply {
            text = "2. Tạo macro mới và mở bảng điều khiển"
            setOnClickListener { openMacro(nameInput.text.toString()) }
        })

        root.addView(TextView(this).apply {
            text = "\nMacro đã lưu:"
            textSize = 16f
        })
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(list)

        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun savePrefs() {
        getSharedPreferences("cfg", MODE_PRIVATE).edit()
            .putLong("interval", (interval.text.toString().toLongOrNull() ?: 800L).coerceAtLeast(50L))
            .putInt("loops", loops.text.toString().toIntOrNull() ?: 0)
            .apply()
    }

    private fun openMacro(name: String) {
        savePrefs()
        val svc = AutoClickService.instance
        if (svc == null) {
            Toast.makeText(this, "Hãy bật dịch vụ trợ năng trước", Toast.LENGTH_LONG).show()
            return
        }
        svc.openMacro(if (name.isBlank()) "macro1" else name)
        moveTaskToBack(true)
    }

    private fun refresh() {
        list.removeAllViews()
        val names = Store.list(this)
        if (names.isEmpty()) {
            list.addView(TextView(this).apply { text = "(chưa có macro nào)" })
            return
        }
        for (name in names) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            row.addView(TextView(this).apply {
                text = name
                textSize = 16f
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            })
            row.addView(Button(this).apply {
                text = "Mở"
                setOnClickListener { openMacro(name) }
            })
            row.addView(Button(this).apply {
                text = "Xóa"
                setOnClickListener {
                    AlertDialog.Builder(this@MainActivity)
                        .setMessage("Xóa macro \"$name\"?")
                        .setPositiveButton("Xóa") { _, _ ->
                            Store.delete(this@MainActivity, name)
                            refresh()
                        }
                        .setNegativeButton("Hủy", null)
                        .show()
                }
            })
            list.addView(row)
        }
    }
}
