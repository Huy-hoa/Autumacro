@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.automacro.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.automacro.engine.JsCheck
import com.example.automacro.engine.MacroLauncher
import com.example.automacro.engine.MacroRuntime
import com.example.automacro.engine.RunState
import com.example.automacro.storage.MacroInfo
import com.example.automacro.storage.MacroRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.max
import kotlin.math.min

@Composable
fun EditorScreen(repo: MacroRepository, id: String, onBack: () -> Unit) {
    val info = remember(id) { repo.get(id) }
    if (info == null) {
        LaunchedEffect(Unit) { onBack() }
    } else {
        EditorBody(repo, info, onBack)
    }
}

private val SNIPPETS = listOf(
    Triple("Tab", "  ", 0), Triple("{}", "{}", 1), Triple("()", "()", 1), Triple("[]", "[]", 1),
    Triple("\"\"", "\"\"", 1), Triple(";", ";", 0), Triple("=", " = ", 0), Triple(".", ".", 0),
    Triple(",", ", ", 0), Triple("'", "'", 0), Triple("+", " + ", 0), Triple("!", "!", 0)
)

@Composable
private fun EditorBody(repo: MacroRepository, info: MacroInfo, onBack: () -> Unit) {
    val id = info.id
    val scope = rememberCoroutineScope()
    val snack = remember { SnackbarHostState() }

    var tf by remember { mutableStateOf(TextFieldValue(repo.readCode(id))) }
    val history = remember { EditHistory() }
    var problem by remember { mutableStateOf<JsCheck.Problem?>(null) }
    var checked by remember { mutableStateOf(false) }
    var findOpen by remember { mutableStateOf(false) }
    var findText by remember { mutableStateOf("") }
    var replText by remember { mutableStateOf("") }
    var findMsg by remember { mutableStateOf("") }
    var matchRange by remember { mutableStateOf<IntRange?>(null) }
    var logOpen by remember { mutableStateOf(false) }

    val runState by MacroRuntime.state.collectAsState()
    val activeId by MacroRuntime.activeId.collectAsState()
    val latest by rememberUpdatedState(tf.text)
    val vScroll = rememberScrollState()
    val hScroll = rememberScrollState()
    val palette = if (isSystemInDarkTheme()) Palette.Dark else Palette.Light
    val lineHeightPx = with(LocalDensity.current) { 20.sp.toPx() }

    val codeStyle = TextStyle(
        fontFamily = FontFamily.Monospace,
        fontSize = 14.sp,
        lineHeight = 20.sp,
        color = MaterialTheme.colorScheme.onSurface
    )
    val gutterStyle = codeStyle.copy(color = MaterialTheme.colorScheme.outline, textAlign = TextAlign.End)

    // Tự động lưu sau 1 giây ngừng gõ, và khi rời màn hình.
    LaunchedEffect(tf.text) {
        delay(1000)
        withContext(Dispatchers.IO) { repo.writeCode(id, tf.text) }
    }
    DisposableEffect(Unit) {
        onDispose { repo.writeCode(id, latest) }
    }
    // Kiểm tra cú pháp tự động sau 0,7 giây.
    LaunchedEffect(tf.text) {
        delay(700)
        problem = withContext(Dispatchers.Default) { JsCheck.check(tf.text) }
        checked = true
    }

    fun jumpToOffset(offset: Int) {
        val o = offset.coerceIn(0, tf.text.length)
        val line = tf.text.substring(0, o).count { it == '\n' }
        scope.launch { vScroll.animateScrollTo(max(0, (line * lineHeightPx).toInt() - 120)) }
    }

    fun gotoLine(line: Int) {
        var off = 0
        var ln = 1
        val t = tf.text
        while (ln < line) {
            val nl = t.indexOf('\n', off)
            if (nl < 0) break
            off = nl + 1
            ln++
        }
        tf = tf.copy(selection = TextRange(off))
        jumpToOffset(off)
    }

    fun onEdit(new: TextFieldValue) {
        if (new.text == tf.text) {
            tf = new
            return
        }
        val adjusted = EditorLogic.autoIndent(tf, new)
        history.record(tf)
        tf = adjusted
        matchRange = null
    }

    fun insert(s: String, back: Int) {
        val start = min(tf.selection.start, tf.selection.end)
        val end = max(tf.selection.start, tf.selection.end)
        val nt = tf.text.replaceRange(start, end, s)
        history.record(tf)
        tf = TextFieldValue(nt, TextRange(start + s.length - back))
        matchRange = null
    }

    fun findNext(from: Int) {
        if (findText.isEmpty()) {
            findMsg = "Nhập nội dung cần tìm"
            return
        }
        var idx = tf.text.indexOf(findText, from.coerceIn(0, tf.text.length))
        if (idx < 0) idx = tf.text.indexOf(findText, 0)
        if (idx < 0) {
            matchRange = null
            findMsg = "Không tìm thấy"
            return
        }
        matchRange = idx until idx + findText.length
        tf = tf.copy(selection = TextRange(idx, idx + findText.length))
        findMsg = ""
        jumpToOffset(idx)
    }

    fun replaceOne() {
        val r = matchRange
        if (r != null && findText.isNotEmpty() && r.last + 1 <= tf.text.length &&
            tf.text.substring(r.first, r.last + 1) == findText
        ) {
            val nt = tf.text.replaceRange(r.first, r.last + 1, replText)
            history.record(tf)
            tf = TextFieldValue(nt, TextRange(r.first + replText.length))
            matchRange = null
        }
        findNext(tf.selection.end)
    }

    fun replaceAll() {
        if (findText.isEmpty()) {
            findMsg = "Nhập nội dung cần tìm"
            return
        }
        val count = tf.text.split(findText).size - 1
        if (count == 0) {
            findMsg = "Không tìm thấy"
            return
        }
        history.record(tf)
        tf = TextFieldValue(tf.text.replace(findText, replText), TextRange(0))
        matchRange = null
        findMsg = "Đã thay $count chỗ"
    }

    fun runIt() {
        scope.launch {
            withContext(Dispatchers.IO) { repo.writeCode(id, tf.text) }
            logOpen = true
            val err = MacroLauncher.launch(repo, info, tf.text)
            if (err != null) snack.showSnackbar(err)
        }
    }

    BackHandler {
        if (findOpen) {
            findOpen = false
            matchRange = null
        } else {
            onBack()
        }
    }

    val transform = remember(palette, matchRange, problem?.line) {
        JsVisualTransformation(palette, matchRange, problem?.line)
    }
    val lineCount = remember(tf.text) { tf.text.count { it == '\n' } + 1 }
    val gutter = remember(lineCount) { (1..lineCount).joinToString("\n") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(info.name, maxLines = 1)
                        Text(
                            "Dòng ${tf.text.substring(0, tf.selection.start.coerceIn(0, tf.text.length)).count { it == '\n' } + 1} · $lineCount dòng",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.outline
                        )
                    }
                },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Quay lại") } },
                actions = {
                    if (runState == RunState.IDLE) {
                        Button(onClick = { runIt() }) { Text("Chạy") }
                    } else if (activeId == id) {
                        FilledTonalButton(onClick = { MacroRuntime.stop() }, enabled = runState == RunState.RUNNING) {
                            Text(if (runState == RunState.STOPPING) "Đang dừng" else "Dừng")
                        }
                    } else {
                        Text("Macro khác đang chạy", fontSize = 11.sp)
                    }
                    Spacer(Modifier.width(8.dp))
                }
            )
        },
        snackbarHost = { SnackbarHost(snack) }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().imePadding()) {
            UnresponsiveBanner()

            // ----- Vùng soạn thảo -----
            Box(Modifier.weight(1f).fillMaxWidth()) {
                Row(Modifier.fillMaxSize().verticalScroll(vScroll)) {
                    Text(gutter, style = gutterStyle, modifier = Modifier.padding(horizontal = 8.dp))
                    Box(Modifier.weight(1f).horizontalScroll(hScroll)) {
                        BasicTextField(
                            value = tf,
                            onValueChange = { onEdit(it) },
                            textStyle = codeStyle,
                            cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
                            softWrap = false,
                            visualTransformation = transform,
                            keyboardOptions = KeyboardOptions(
                                capitalization = KeyboardCapitalization.None,
                                autoCorrect = false
                            ),
                            modifier = Modifier.defaultMinSize(minWidth = 360.dp, minHeight = 480.dp)
                        )
                    }
                }
            }

            // ----- Trạng thái cú pháp -----
            val p = problem
            if (p != null) {
                Text(
                    "Lỗi dòng ${p.line ?: "?"}: ${p.message}",
                    color = MaterialTheme.colorScheme.error,
                    fontSize = 12.sp,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { p.line?.let { gotoLine(it) } }
                        .padding(horizontal = 12.dp, vertical = 4.dp)
                )
            } else if (checked) {
                Text(
                    "✓ Cú pháp hợp lệ",
                    color = Color(0xFF2E7D32),
                    fontSize = 12.sp,
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp)
                )
            }

            // ----- Tìm / thay thế -----
            if (findOpen) {
                Surface(tonalElevation = 3.dp) {
                    Column(Modifier.fillMaxWidth().padding(8.dp)) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = findText,
                                onValueChange = { findText = it; matchRange = null; findMsg = "" },
                                label = { Text("Tìm") },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedTextField(
                                value = replText,
                                onValueChange = { replText = it },
                                label = { Text("Thay bằng") },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            TextButton(onClick = { findNext(tf.selection.end) }) { Text("Tìm tiếp") }
                            TextButton(onClick = { replaceOne() }) { Text("Thay") }
                            TextButton(onClick = { replaceAll() }) { Text("Thay hết") }
                            TextButton(onClick = { findOpen = false; matchRange = null }) { Text("Đóng") }
                            Text(findMsg, fontSize = 12.sp, color = MaterialTheme.colorScheme.outline)
                        }
                    }
                }
            }

            // ----- Phím ký hiệu nhanh -----
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                verticalAlignment = Alignment.CenterVertically
            ) {
                SNIPPETS.forEach { (label, text, back) ->
                    TextButton(
                        onClick = { insert(text, back) },
                        contentPadding = PaddingValues(horizontal = 12.dp)
                    ) { Text(label, fontFamily = FontFamily.Monospace) }
                }
            }

            // ----- Thanh công cụ -----
            Row(
                Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surfaceVariant).horizontalScroll(rememberScrollState()),
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextButton(onClick = { history.undo(tf)?.let { tf = it; matchRange = null } }) { Text("Hoàn tác") }
                TextButton(onClick = { history.redo(tf)?.let { tf = it; matchRange = null } }) { Text("Làm lại") }
                TextButton(onClick = { findOpen = !findOpen }) { Text("Tìm/Thay") }
                TextButton(onClick = {
                    scope.launch {
                        val r = withContext(Dispatchers.Default) { JsCheck.check(tf.text) }
                        problem = r
                        checked = true
                        snack.showSnackbar(
                            if (r == null) "Cú pháp hợp lệ"
                            else "Lỗi cú pháp" + (if (r.line != null) " dòng ${r.line}" else "") + ": " + r.message
                        )
                    }
                }) { Text("Kiểm tra") }
                TextButton(onClick = { logOpen = !logOpen }) { Text(if (logOpen) "Ẩn nhật ký" else "Nhật ký") }
            }

            if (logOpen) {
                LogPanel(Modifier.fillMaxWidth().height(190.dp))
            }
        }
    }
}
