package com.example.automacro

import android.graphics.Bitmap
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/** So khớp ảnh mẫu nhẹ (thang xám, SAD, tìm thô rồi tinh chỉnh). Không cần OpenCV. */
object Matcher {
    class Gray(val w: Int, val h: Int, val d: ByteArray)

    class Hit(val x: Int, val y: Int, val w: Int, val h: Int, val score: Float) {
        val cx: Int get() = x + w / 2
        val cy: Int get() = y + h / 2
    }

    private class Best(var x: Int, var y: Int, var sad: Long)

    fun toGray(b: Bitmap): Gray {
        val w = b.width
        val h = b.height
        val px = IntArray(w * h)
        b.getPixels(px, 0, w, 0, 0, w, h)
        val g = ByteArray(w * h)
        for (i in px.indices) {
            val c = px[i]
            val r = (c shr 16) and 255
            val gg = (c shr 8) and 255
            val bb = c and 255
            g[i] = ((r * 77 + gg * 150 + bb * 29) shr 8).toByte()
        }
        return Gray(w, h, g)
    }

    private fun down(g: Gray, s: Int): Gray {
        if (s == 1) return g
        val w = g.w / s
        val h = g.h / s
        val out = ByteArray(w * h)
        val area = s * s
        for (y in 0 until h) {
            for (x in 0 until w) {
                var sum = 0
                for (dy in 0 until s) {
                    val row = (y * s + dy) * g.w + x * s
                    for (dx in 0 until s) sum += g.d[row + dx].toInt() and 255
                }
                out[y * w + x] = (sum / area).toByte()
            }
        }
        return Gray(w, h, out)
    }

    private fun search(img: Gray, t: Gray, x0: Int, y0: Int, x1: Int, y1: Int, st: Int): Best {
        val best = Best(x0, y0, Long.MAX_VALUE)
        val id = img.d
        val td = t.d
        for (y in y0..y1) {
            for (x in x0..x1) {
                var sad = 0L
                var ty = 0
                var ok = true
                while (ty < t.h) {
                    val si = (y + ty) * img.w + x
                    val ti = ty * t.w
                    var tx = 0
                    while (tx < t.w) {
                        sad += abs((id[si + tx].toInt() and 255) - (td[ti + tx].toInt() and 255))
                        tx += st
                    }
                    if (sad >= best.sad) { ok = false; break }
                    ty += st
                }
                if (ok && sad < best.sad) { best.sad = sad; best.x = x; best.y = y }
            }
        }
        return best
    }

    fun find(screen: Bitmap, tpl: Bitmap): Hit? {
        val sg = toGray(screen)
        val tg = toGray(tpl)
        if (tg.w < 8 || tg.h < 8 || tg.w > sg.w || tg.h > sg.h) return null
        val m = min(tg.w, tg.h)
        val s = if (m >= 48) 4 else if (m >= 24) 2 else 1
        val sd = down(sg, s)
        val td = down(tg, s)
        if (td.w > sd.w || td.h > sd.h) return null

        val c = search(sd, td, 0, 0, sd.w - td.w, sd.h - td.h, if (s == 1) 2 else 1)
        if (c.sad == Long.MAX_VALUE) return null

        val cx = c.x * s
        val cy = c.y * s
        val r = s * 2 + 1
        val f = search(
            sg, tg,
            max(0, cx - r), max(0, cy - r),
            min(sg.w - tg.w, cx + r), min(sg.h - tg.h, cy + r), 2
        )
        if (f.sad == Long.MAX_VALUE) return null
        val count = ((tg.h + 1) / 2) * ((tg.w + 1) / 2)
        val score = (1.0 - f.sad.toDouble() / (255.0 * count)).toFloat()
        return Hit(f.x, f.y, tg.w, tg.h, score)
    }

    /** Độ lệch chuẩn của độ sáng: thấp = vùng đơn sắc, khó nhận diện. */
    fun stdDev(b: Bitmap): Double {
        val g = toGray(b)
        var sum = 0.0
        var sq = 0.0
        for (v in g.d) {
            val x = (v.toInt() and 255).toDouble()
            sum += x
            sq += x * x
        }
        val n = g.d.size.toDouble()
        val mean = sum / n
        return sqrt(max(0.0, sq / n - mean * mean))
    }
}
