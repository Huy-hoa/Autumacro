package com.example.automacro.engine

import android.os.SystemClock
import app.cash.quickjs.QuickJs
import com.example.automacro.logging.LogLevel
import com.example.automacro.logging.LogStore
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

enum class RunState { IDLE, RUNNING, STOPPING }

object ErrorInfo {
    fun line(e: Throwable): Int? {
        e.stackTrace.firstOrNull { it.fileName == "macro.js" && it.lineNumber > 0 }?.let { return it.lineNumber }
        val text = (e.message ?: "") + "\n" + e.stackTraceToString()
        Regex("macro\\.js:(\\d+)").find(text)?.let { return it.groupValues[1].toIntOrNull() }
        return null
    }

    fun message(e: Throwable): String =
        (e.message ?: e.javaClass.simpleName).lineSequence().firstOrNull() ?: e.javaClass.simpleName
}

object JsCheck {
    class Problem(val line: Int?, val message: String)

    /** Kiểm tra cú pháp bằng cách biên dịch (không chạy). Trả về null nếu hợp lệ. */
    fun check(code: String): Problem? {
        var qjs: QuickJs? = null
        return try {
            qjs = QuickJs.create()
            qjs.compile(code, "macro.js")
            null
        } catch (e: Throwable) {
            Problem(ErrorInfo.line(e), ErrorInfo.message(e))
        } finally {
            try { qjs?.close() } catch (_: Throwable) {}
        }
    }
}

object MacroRuntime {
    private val _state = MutableStateFlow(RunState.IDLE)
    val state: StateFlow<RunState> = _state
    private val _activeId = MutableStateFlow<String?>(null)
    val activeId: StateFlow<String?> = _activeId
    private val _unresponsive = MutableStateFlow(false)
    val unresponsive: StateFlow<Boolean> = _unresponsive

    @Volatile private var ctl: RunControl? = null
    @Volatile private var thread: Thread? = null

    @Synchronized
    fun start(id: String, name: String, code: String): Boolean {
        if (_state.value != RunState.IDLE) return false
        val c = RunControl()
        ctl = c
        _activeId.value = id
        _unresponsive.value = false
        _state.value = RunState.RUNNING
        val t = Thread({ run(c, name, code) }, "macro-run")
        thread = t
        t.start()
        return true
    }

    fun stop() {
        val c = ctl ?: return
        if (_state.value != RunState.RUNNING) return
        c.stop = true
        _state.value = RunState.STOPPING
        LogStore.add(LogLevel.INFO, "Đang dừng macro...", "runtime")
        val t = thread
        Thread {
            try { Thread.sleep(3000) } catch (_: InterruptedException) {}
            if (t != null && t.isAlive && _state.value == RunState.STOPPING) {
                _unresponsive.value = true
                LogStore.add(
                    LogLevel.ERROR,
                    "Macro không phản hồi lệnh dừng: vòng lặp không gọi Time.delay() hay Log. " +
                        "Hãy thêm Time.delay(...) trong vòng lặp. Có thể đóng ứng dụng để dừng ngay.",
                    "runtime"
                )
            }
        }.start()
    }

    fun forceKill() {
        android.os.Process.killProcess(android.os.Process.myPid())
    }

    private fun run(c: RunControl, name: String, code: String) {
        val t0 = SystemClock.elapsedRealtime()
        fun took() = SystemClock.elapsedRealtime() - t0
        LogStore.add(LogLevel.INFO, "▶ Bắt đầu chạy: $name", "runtime")
        var qjs: QuickJs? = null
        try {
            qjs = QuickJs.create()
            JsBridge.install(qjs, c, name)
            qjs.evaluate(JsBridge.PRELUDE, "prelude.js")
            qjs.evaluate(code, "macro.js")
            LogStore.add(LogLevel.INFO, "■ Macro kết thúc (${took()} ms)", "runtime")
        } catch (e: Throwable) {
            when {
                c.exited -> LogStore.add(LogLevel.INFO, "■ Macro thoát bằng Sys.exit() (${took()} ms)", "runtime")
                c.stop -> LogStore.add(LogLevel.INFO, "■ Macro đã dừng (${took()} ms)", "runtime")
                else -> {
                    val line = ErrorInfo.line(e)
                    val where = if (line != null) " (dòng $line)" else ""
                    LogStore.add(LogLevel.ERROR, "Lỗi$where: ${ErrorInfo.message(e)}", name)
                }
            }
        } finally {
            try { qjs?.close() } catch (_: Throwable) {}
            thread = null
            ctl = null
            _activeId.value = null
            _unresponsive.value = false
            _state.value = RunState.IDLE
        }
    }
}
