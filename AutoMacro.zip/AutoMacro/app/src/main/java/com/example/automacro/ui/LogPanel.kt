@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.automacro.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.automacro.engine.MacroRuntime
import com.example.automacro.logging.LogEntry
import com.example.automacro.logging.LogLevel
import com.example.automacro.logging.LogStore

@Composable
fun rememberLogExporter(): () -> Unit {
    val ctx = LocalContext.current
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        if (uri != null) {
            runCatching {
                ctx.contentResolver.openOutputStream(uri)?.use { it.write(LogStore.asText().toByteArray()) }
            }
        }
    }
    return { launcher.launch("automacro-log.txt") }
}

@Composable
fun UnresponsiveBanner() {
    val bad by MacroRuntime.unresponsive.collectAsState()
    if (!bad) return
    Surface(color = MaterialTheme.colorScheme.errorContainer, modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(
                "Macro không phản hồi lệnh dừng (vòng lặp thiếu Time.delay).",
                modifier = Modifier.weight(1f),
                color = MaterialTheme.colorScheme.onErrorContainer,
                fontSize = 13.sp
            )
            Button(onClick = { MacroRuntime.forceKill() }) { Text("Đóng app") }
        }
    }
}

private fun levelColor(l: LogLevel, base: Color): Color = when (l) {
    LogLevel.ERROR -> Color(0xFFE53935)
    LogLevel.WARN -> Color(0xFFF57C00)
    LogLevel.DEBUG -> Color(0xFF8E8E8E)
    LogLevel.INFO -> base
}

@Composable
private fun LogLine(e: LogEntry) {
    val base = MaterialTheme.colorScheme.onSurface
    val text = buildAnnotatedString {
        withStyle(SpanStyle(color = Color(0xFF8E8E8E))) { append(LogStore.timeText(e.time) + " ") }
        withStyle(SpanStyle(color = levelColor(e.level, base))) { append("[" + e.level.tag + "] " + e.msg) }
    }
    Text(text, fontFamily = FontFamily.Monospace, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 8.dp, vertical = 1.dp))
}

@Composable
fun LogPanel(modifier: Modifier = Modifier) {
    val entries by LogStore.entries.collectAsState()
    var auto by remember { mutableStateOf(true) }
    val state = rememberLazyListState()
    val export = rememberLogExporter()
    LaunchedEffect(entries.size, entries.lastOrNull()?.time, auto) {
        if (auto && entries.isNotEmpty()) state.scrollToItem(entries.lastIndex)
    }
    Surface(modifier = modifier, tonalElevation = 2.dp) {
        Column(Modifier.fillMaxSize()) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("Nhật ký (${entries.size})", modifier = Modifier.weight(1f).padding(start = 12.dp), fontSize = 13.sp)
                TextButton(onClick = { auto = !auto }, contentPadding = PaddingValues(horizontal = 8.dp)) {
                    Text(if (auto) "Tự cuộn: Bật" else "Tự cuộn: Tắt", fontSize = 12.sp)
                }
                TextButton(onClick = { LogStore.clear() }, contentPadding = PaddingValues(horizontal = 8.dp)) {
                    Text("Xóa", fontSize = 12.sp)
                }
                TextButton(onClick = export, contentPadding = PaddingValues(horizontal = 8.dp)) {
                    Text("Lưu", fontSize = 12.sp)
                }
            }
            SelectionContainer(Modifier.weight(1f)) {
                LazyColumn(state = state, modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.Top) {
                    items(entries) { e -> LogLine(e) }
                }
            }
        }
    }
}

@Composable
fun LogsScreen(onBack: () -> Unit) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Nhật ký hoạt động") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Quay lại") } }
            )
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            UnresponsiveBanner()
            LogPanel(Modifier.weight(1f).fillMaxWidth())
        }
    }
}
