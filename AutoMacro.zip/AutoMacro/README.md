# AutoMacro 3.0 – Giai đoạn 1: Nền tảng

## Build APK (trên điện thoại, qua GitHub)
1. Tải AutoMacro.zip này lên repo (cùng tên, ghi đè bản cũ), Commit.
2. Tab Actions > chờ "Build APK" có dấu ✓ xanh (lần đầu 5–10 phút vì tải Compose/QuickJS).
3. Tải artifact AutoMacro-apk, giải nén, cài app-debug.apk.
Workflow cũ (unzip AutoMacro.zip; cd AutoMacro; gradle assembleDebug) dùng được nguyên.

## Đã triển khai (chưa kiểm thử trên thiết bị thật)
- Trang chủ: danh sách macro, lọc theo thư mục, Chạy/Dừng, trạng thái bộ chạy.
- Quản lý macro: tạo, đổi tên/mô tả/thư mục/phiên bản, sao chép, xóa, nhập/xuất .mcr, sao lưu/khôi phục.
- Trình soạn thảo: tô màu cú pháp JS, đánh số dòng, tự thụt lề, tìm/thay thế, hoàn tác/làm lại,
  phím ký hiệu nhanh, tự động lưu, kiểm tra cú pháp (hiện lỗi + số dòng, chạm để nhảy tới dòng).
- JavaScript Engine: QuickJS. API: Log, console, Time.delay/delaySec/now/elapsed, Sys.exit.
- Nhật ký: mức INFO/CẢNH BÁO/LỖI/DEBUG, xóa, lưu ra tệp, tự cuộn.
- Giữ nguyên công cụ chạm bằng bảng nổi bản 2.0 (menu ⋮ > Công cụ chạm bằng bảng nổi).

## Chưa làm
Ảnh đại diện macro, lịch sử chạy riêng, tạm dừng/tiếp tục, chạy nền bằng Foreground Service,
Room (đang dùng tệp), tách đa module, toàn bộ API Touch/Screen/Region/Image/Color/OCR/Overlay/Setting/Env/File.

## Lỗi/giới hạn đã biết
- Vòng lặp không gọi Log/Time/Sys (vd while(true){}) không dừng được (QuickJS bản này không có ngắt). App hiện nút "Đóng app".
- Macro chạy trong tiến trình app: bị hệ thống đóng thì macro dừng.

## Kiểm thử thủ công Giai đoạn 1
1. Tạo macro, chạy macro mẫu: nhật ký hiện 3 vòng rồi "Macro kết thúc".
2. Sửa thành while(true){Time.delay(200)}, chạy rồi bấm Dừng: phải dừng trong <1 giây.
3. Gõ sai cú pháp (thiếu dấu ngoặc): hiện lỗi + số dòng, nút Chạy báo lỗi cú pháp.
4. Nhập Enter sau dấu { : tự thụt lề. Thử Tìm/Thay, Hoàn tác/Làm lại.
5. Xuất .mcr, xóa macro, nhập lại: nội dung giống cũ. Thử Sao lưu rồi Khôi phục.
6. Thoát app, mở lại: macro và nội dung còn nguyên.
