# AutoMacro 2.0
- Bước: Chạm, Vuốt, Chờ, Ảnh (tìm ảnh mẫu trên màn hình rồi chạm; cần Android 11+).
- Macro được lưu trong bộ nhớ app; ảnh mẫu lưu dạng PNG.
- Build: giữ nguyên workflow GitHub Actions cũ, tải lại AutoMacro.zip cùng tên rồi chờ build.
